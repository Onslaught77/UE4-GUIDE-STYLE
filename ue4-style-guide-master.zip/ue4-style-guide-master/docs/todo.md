# The Future of Linter and the Gamemakin LLC Style Guide

This page documents active efforts with Linter and the Gamemakin LLC Style Guide that may be in progress or otherwise incomplete.

## Planned Future Features

1. Finish video tutorial on the creation of a new lint ruleset
1. Allowing rule scanning to support multiple class matches in a class lint rules map

## Future Considerations

* Figure out a way to facilitate community lint rule sets