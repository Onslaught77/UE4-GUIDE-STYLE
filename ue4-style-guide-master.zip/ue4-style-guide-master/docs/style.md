# Gamemakin LLC Style Guide

For information about how Linter scans against the Gamemakin LLC Style Guide, please see the style guide itself at [http://ue4.style](http://ue4.style) as the style guide is marked up with its own Linter annotations.